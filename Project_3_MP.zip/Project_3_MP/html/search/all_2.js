var searchData=
[
  ['file_5fin_5fdirectory_0',['file_in_directory',['../namespacebackup.html#a5e84dfe03108f511976295537fd95072',1,'backup']]],
  ['final_5ffunc_1',['final_func',['../namespacebackup.html#a1da674d47bf1981858b5c34d789bf20b',1,'backup']]]
];
