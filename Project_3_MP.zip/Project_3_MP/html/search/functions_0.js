var searchData=
[
  ['backup_5fparm_5fexists_0',['backup_parm_exists',['../namespacebackup.html#afd761d05cc4617eacaa153fbf5be13de',1,'backup']]],
  ['backup_5frestore_1',['backup_restore',['../namespacebackup.html#ade12221ef0024a68d8ee72257765b991',1,'backup']]]
];
