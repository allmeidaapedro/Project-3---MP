var searchData=
[
  ['test_5fbackup_5fparm_5fexists_0',['test_backup_parm_exists',['../namespacetest__backup.html#a734394ca8d7fde81acaa80e94d044c78',1,'test_backup']]],
  ['test_5fbackup_5frestore_1',['test_backup_restore',['../namespacetest__backup.html#aa7dcb92f5fe6a7309136c5e3b6a9bb0d',1,'test_backup']]],
  ['test_5fdate_5fof_5fmodification_2',['test_date_of_modification',['../namespacetest__backup.html#a7748a3d04083f93adc3499216dc6d457',1,'test_backup']]],
  ['test_5ffile_5fin_5fdirectory_3',['test_file_in_directory',['../namespacetest__backup.html#a042673af2884c837db7f5cb7fc514300',1,'test_backup']]],
  ['test_5ffinal_5ffunc_4',['test_final_func',['../namespacetest__backup.html#a255cb9a50f7509141d4b55dcae09ca3e',1,'test_backup']]]
];
