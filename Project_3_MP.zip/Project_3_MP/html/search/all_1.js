var searchData=
[
  ['date_5fof_5fmodification_0',['date_of_modification',['../namespacebackup.html#aa34aa2d1869c3a8b3b094ac0c8b3a3d7',1,'backup']]]
];
