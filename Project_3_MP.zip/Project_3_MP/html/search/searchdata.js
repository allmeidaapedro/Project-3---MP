var indexSectionsWithContent =
{
  0: "bdft",
  1: "bt",
  2: "bt",
  3: "bdft"
};

var indexSectionNames =
{
  0: "all",
  1: "namespaces",
  2: "files",
  3: "functions"
};

var indexSectionLabels =
{
  0: "All",
  1: "Namespaces",
  2: "Files",
  3: "Functions"
};

