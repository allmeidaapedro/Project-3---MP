'''Arquivo executável'''

import os
import shutil
from typing import Union

def backup_parm_exists(file):
    '''! Função que verifica a existência do arquivo "Backup.parm"

    Assertiva de entrada:\n
        file - nome do arquivo, no caso, "Backup.parm". \n
    Assertiva de saída: \n
            Se os.path.isfile(arquivo) == True \n
            Então o arquivo existe, função retorna True \n
            Se não, o arquivo não existe, função retorna False

    '''
    if os.path.isfile(file):
        return True
    return False


def file_in_directory(dir_path: str, file: str) -> bool:
    '''! Função que verifica se o arquivo x pertence ao HD e/ou ao Pen-drive

        Assertiva de entrada:
            dir_path - caminho do diretório
            file - nome do arquivo

        Assertiva de saída:
            Se directory_files não for uma lista vazia
            Então o arquivo pertence ao diretório passado, função retorna True
            Se não, o arquivo não pertence ao diretório passado, função retorna False
    '''
    directory_files = [archive for archive in os.listdir(dir_path) if archive == file]
    if directory_files:
        return True
    return False

def date_of_modification(hd_file_path: str, pendrive_file_path: str) -> tuple:
    '''! Função que compara as datas de modificação dos dois arquivos

        Assertiva de entrada:
            hd_file_path - caminho do arquivo no hd
            pendrive_file_path - caminho do arquivo no pen-drive

        Assertiva de saída:
            Se data de modificação do arquivo no pendrive for menor que a data do arquivo no hd
            Então a função retorna uma tupla com o caminho do arquivo de maior data,
            e uma string indicando que este está no hd e é maior

            Se a data de modificação de ambos foram iguais
            Então a função retorna uma tupla com o caminho dos dois arquivos e uma string indicando
            que tem iguais datas

            Se a data de modificação do arquivo no pendrive for maior que a data do arquivo no hd
            Então a função retorna uma tupla, com o caminho do arquivo no pen-drive e uma string
            indicando que este é o maior

    '''
    date_hd_file = os.path.getmtime(hd_file_path)
    date_pendrive_file = os.path.getmtime(pendrive_file_path)
    if date_pendrive_file < date_hd_file:
        return hd_file_path, 'hd maior'
    if date_pendrive_file > date_hd_file:
        return pendrive_file_path, 'pendrive maior'
    return hd_file_path, pendrive_file_path, 'igual'


def backup_restore(origin_file_path: str, destination_directory: str) -> None:
    '''! Função que realiza o backup e a restauração (caminho inverso

        Assertiva de entrada:
            origin_file_path - caminho do arquivo de origem, que desejamos copiar
            destination_directory - caminho do diretório de destino

        Assertiva de saída:
            A função não retorna nada. Deve ser copiado o arquivo para o diretório
            de destino.

    '''
    shutil.copy(origin_file_path, destination_directory)


# olhar o mypy
def final_func(backupparm_exists: bool, option: bool, hd_path: str, pendrive_path: str,
               file_name: str) -> Union[str, bool]:
    '''! Função final, que executa de uma vez o programa,
    utilizando funções auxiliares definidas acima.

    Assertiva de entrada: \n
        backupparm_exists - verdadeira ou falsa existência ou não de 'Backup.parm' pela função \n
        backup_parm_exists
        option - verdadeiro ou falso o desejo de realizar um backup \n
        hd_path - caminho até o diretório do HD \n
        pendrive_path - caminho até o diretório do Pen-drive \n
        file_name - nome do arquivo a ser trabalhado \n

    Assertiva de saída: \n
        (autoexplicativos) \n
        todos os retornos guardados em uma variável "operation"
        retorna False se o arquivo "Backup.parm" não existe \n
        retorna 'HOUVE UM ERRO. Data de modificação do arquivo do Pen-drive é maior.' \n
        retorna 'HOUVE UM ERRO. O arquivo não pertence nem ao HD, nem ao Pen-drive' \n
        retorna 'HOUVE UM ERRO. O arquivo está no HD e não no Pen-drive.' \n
        retorna 'HOUVE UM ERRO. Data de modificação do arquivo do HD é maior.' \n
        retorna 'HOUVE UM ERRO. O arquivo não está nem no HD nem no Pen-drive.' \n
        retorna 'HD -> PEN-DRIVE' quando ocorre esta operação (backup) \n
        retorna 'PEN-DRIVE -> HD' quando ocorre esta operação (restauração) \n
        retorna 'Nada feito' quando não se pode fazer nada
    '''

    if not backupparm_exists:
        return False

    if option is True: # faz backup
        # verificar onde está o arquivo que deseja-se fazer backup
        if file_in_directory(rf'{hd_path}', file_name) and not \
                file_in_directory(rf'{pendrive_path}', file_name):
            # pode fazer backup HD -> PENDRIVE
            backup_restore(hd_path+'/'+file_name, rf'{pendrive_path}')
            operation = 'HD -> PEN-DRIVE'
            print(operation)
            return operation
        if file_in_directory(rf'{hd_path}', file_name) and \
                file_in_directory(rf'{pendrive_path}', file_name):
            if date_of_modification(hd_path+'/'+file_name, pendrive_path+'/'+file_name)[1] \
                    == 'hd maior':
                backup_restore(hd_path+'/'+file_name, rf'{pendrive_path}')
                operation = 'HD -> PEN-DRIVE'
                print(operation)
                return operation
            if date_of_modification(hd_path+'/'+file_name, pendrive_path+'/'+file_name)[1] \
                    == 'igual':
                operation = 'Nada feito'
                print(operation)
                return operation
            if date_of_modification(hd_path+'/'+file_name, pendrive_path+'/'+file_name)[1] \
                    == 'pendrive maior':
                operation = 'HOUVE UM ERRO. Data de modificação do arquivo do Pen-drive é maior.'
                print(operation)
                return operation
        if not file_in_directory(rf'{hd_path}', file_name) \
                and not file_in_directory(rf'{pendrive_path}', file_name):
            operation = 'HOUVE UM ERRO. O arquivo não pertence nem ao HD, nem ao Pen-drive'
            print(operation)
            return operation
        if not file_in_directory(rf'{hd_path}', file_name) and \
                file_in_directory(rf'{pendrive_path}', file_name):
            operation = 'Nada feito'
            print(operation)
            return operation

    else:
        if file_in_directory(rf'{hd_path}', file_name) and not \
                file_in_directory(rf'{pendrive_path}', file_name):
            operation = 'HOUVE UM ERRO. O arquivo está no HD e não no Pen-drive.'
            print(operation)
            return operation
        if file_in_directory(rf'{hd_path}', file_name) and \
                file_in_directory(rf'{pendrive_path}', file_name):
            if date_of_modification(hd_path+'/'+file_name, pendrive_path+'/'+file_name)[1] \
                    == 'hd maior':
                operation = 'HOUVE UM ERRO. ' \
                       'Data de modificação do arquivo do HD é maior.'
                print(operation)
                return operation
            if date_of_modification(hd_path+'/'+file_name, pendrive_path+'/'+file_name)[1] \
                    == 'igual':
                operation = 'Nada feito'
                print(operation)
                return operation
            if date_of_modification(hd_path+'/'+file_name, pendrive_path+'/'+file_name)[1] \
                    == 'pendrive maior':
                backup_restore(pendrive_path+'/'+file_name, rf'{hd_path}')
                operation = 'PEN-DRIVE -> HD'
                print(operation)
                return operation
        if not file_in_directory(rf'{hd_path}', file_name) and \
                not file_in_directory(rf'{pendrive_path}', file_name):
            operation = 'HOUVE UM ERRO. O arquivo não está nem no HD nem no Pen-drive.'
            print(operation)
            return operation
        if not file_in_directory(rf'{hd_path}', file_name) \
                and file_in_directory(rf'{pendrive_path}', file_name):
            backup_restore(pendrive_path + '/' + file_name, rf'{hd_path}')
            operation = 'PEN-DRIVE -> HD'
            print(operation)
            return operation
    return True

if __name__ == '__main__':
    # chame a função aqui
    pass
