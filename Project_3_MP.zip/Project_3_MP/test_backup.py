'''Testes para backup.py'''

import os
import filecmp
import pytest

from backup import backup_parm_exists
from backup import file_in_directory
from backup import date_of_modification
from backup import backup_restore
from backup import final_func


@pytest.mark.backup_parm
def test_backup_parm_exists():
    '''! Funcão que testa se o arquivo
    "Backup.parm" existe'''
    assert backup_parm_exists('Backup.parm')
    assert backup_parm_exists('Backup.parm1') is not True

@pytest.mark.file_in_directory
def test_file_in_directory():
    '''! Função que testa se o arquivo x pertence ao HD e/ou ao Pen-drive'''
    assert file_in_directory(r'Pen-drive', 'Arquivo 4')
    assert file_in_directory(r'HD', 'Arquivo 1')
    assert not file_in_directory(r'Pen-drive', 'Arquivo 3')
    assert not file_in_directory(r'HD', 'Arquivo 6')

@pytest.mark.date_of_modification
def test_date_of_modification():
    '''! Função que testa se as datas de modificação dos dois arquivos estão sendo
    corretamente comparadas'''
    assert date_of_modification('HD/Arquivo 1', 'Pen-drive/Arquivo 6') == \
           ('Pen-drive/Arquivo 6', 'pendrive maior')
    assert date_of_modification('HD/Arquivo 3', 'Pen-drive/Arquivo 5') == \
           ('HD/Arquivo 3', 'hd maior')

@pytest.mark.backup_restore
def test_backup_restore():
    '''! Função que testa se a transferência / cópias de arquivos de
    para um diretório de destino está sendo feita corretamente'''

    backup_restore('HD2/Arquivo 1', r'Pen-drive2')
    backup_restore('Pen-drive2/Arquivo 6', r'HD2')
    assert filecmp.cmp('HD2/Arquivo 1', 'Pen-drive2/Arquivo 1')
    assert filecmp.cmp('Pen-drive2/Arquivo 6', 'HD2/Arquivo 6')
    assert filecmp.cmp('HD2/Arquivo 1', 'Pen-drive2/Arquivo 1')

@pytest.mark.final_func
def test_final_func():
    '''! Função que testa a função final, de execução do programa'''
    is_backupparm1 = backup_parm_exists('Backup.parm1')
    is_backupparm = backup_parm_exists('Backup.parm')
    # Não existe o arquivo "Backup.parm"
    # Os outros testes, se passam, indicam que "Backup.parm" existe
    assert not final_func(is_backupparm1, True, 'HD3', 'Pen-drive3', 'Arquivo A')
    # Backup -> Arquivo pertence ao Pen-Drive e não ao HD -> Faz nada
    assert final_func(is_backupparm, True, 'HD3', 'Pen-drive3', 'So Em PD') == 'Nada feito'
    # Erro -> Backup -> Arquivo em ambos -> Data PD > Data HD
    assert final_func(is_backupparm, True, 'HD4', 'Pen-drive4', 'Arquivo Comum') ==\
           'HOUVE UM ERRO. Data de modificação do arquivo do Pen-drive é maior.'
    # Erro -> Restauração -> Arquivo pertence ao HD e não ao Pen-drive
    assert final_func(is_backupparm, False, 'HD4', 'Pen-drive4', 'Arquivo AA') == \
           'HOUVE UM ERRO. O arquivo está no HD e não no Pen-drive.'
    # Erro -> Restauração -> Arquivo pertence ao HD e ao Pen-drive -> Data de modificação
    # do arquivo no HD é maior que o do Pen-drive
    assert final_func(is_backupparm, False, 'HD4', 'Pen-drive4', 'Arquivo Comum 1') == \
           'HOUVE UM ERRO. Data de modificação do arquivo do HD é maior.'
    # Erro -> Backup -> Arquivo não pertence a nenhum dos dois (HD e Pen-drive)
    assert final_func(is_backupparm, True, 'HD4', 'Pen-drive4', 'Não Pertence') == \
           'HOUVE UM ERRO. O arquivo não pertence nem ao HD, nem ao Pen-drive'
    # Erro -> Restauração -> Arquivo não pertence a nenhum dos dois (HD e Pen-drive)
    assert final_func(is_backupparm, False, 'HD4', 'Pen-drive4', 'Não Perence') == \
           'HOUVE UM ERRO. O arquivo não está nem no HD nem no Pen-drive.'
    # Backup -> Arquivo pertence ao HD e não ao Pen-drive -> HD para Pen-drive
    assert final_func(is_backupparm, True, 'HD4', 'Pen-drive4', 'Arquivo CC') == \
           'HD -> PEN-DRIVE'
    assert os.path.exists('Pen-drive4/Arquivo CC')
    # Backup -> Arquivo pertence a ambos -> Data de modificação do arquivo no HD é maior que
    # a do arquivo no Pen-drive
    assert final_func(is_backupparm, True, 'HD4', 'Pen-drive4', 'Arquivo Comum 2') \
           == 'HD -> PEN-DRIVE'
    assert filecmp.cmp('HD4/Arquivo Comum 2', 'Pen-drive4/Arquivo Comum 2')
    # Restauração -> Arquivo pertence a ambos -> Data de modificação do arquivo no Pen-drive é
    # maior que a do arquivo no HD
    assert final_func(is_backupparm, False, 'HD4', 'Pen-drive4', 'Arquivo Comum 3') \
           == 'PEN-DRIVE -> HD'
    assert filecmp.cmp('Pen-drive4/Arquivo Comum 3', 'HD4/Arquivo Comum 3')
    # Restauração -> Arquivo pertence somente ao Pen-drive
    assert final_func(is_backupparm, False, 'HD4', 'Pen-drive4', 'Arquivo FF') == \
           'PEN-DRIVE -> HD'
    assert os.path.exists('HD4/Arquivo FF')
